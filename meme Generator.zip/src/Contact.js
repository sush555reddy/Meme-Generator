import React from 'react';
import './Header.css';

function Contact(props) {
    return (
        <div >
            <p>Name: {props.employee_name}</p>
            <p>Salary: {props.employee_salary}</p>
            <p>DOB: {props.DOB}</p>
            <br/>
        </div>
    )

}

export default Contact;