import React from "react";

function Nav(){
return(
    <header>
        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRvNQVJp6Ve8SBYpqvN8DtdrX5irbB2nqEokywlqFP8PKDLYqxT" alt="problem"/>
    <h1>Meme Generator Section</h1>
    </header>

)
}
export default Nav;