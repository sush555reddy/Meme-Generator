import React, { Component } from 'react';
//import ReactDOM from 'react-dom';
// import MyInfo from "./MyInfo";
// import Header from "./Header";
// import Contact from "./Contact";
// import Todo from './Todo';
import './App.css';
//import todoitemData from './ContactDate';


// function App() {
//   const todoitem = todoitemData.map(item =>
//     <Todo key={item.id} text={item.text} completed={item.completed} />);
//   // const employeeComponent = employeeData.map(employee =>
//   //   <Contact key ={employee.id} employee_name = {employee.employee_name} 
//   //   employee_salary ={employee.employee_salary}
//   //   DOB = {employee.DOB}/>)
//   return (
//     <div>
//       <Header />
//       {/*  {employeeComponent} */}
//       {todoitem}
//       {/* <Contact contact= {{name:"Madireddy Sushmmitha",phone :"6605280511", email:"mrsushmitha04@gmail.com"}}/>
//    <Contact contact= {{ name:"Komal", phone:"660-212-0414", email:"fsdf@gmail.com"}}/>
//    <Contact contact= {{name:"Nani", phone:"660-782-0414", email:"opdf@gmail.com"}}/>
//    <Contact contact= {{name:"Sravanthi", phone:"660-278-0414",email:"kopf@gmail.com"}}/>
//    <MyInfo/>
//    <Todo/> */}
//     </div>
//   );
// }


class App extends Component {
  constructor() {
    super()
    this.state = {
      // todo:todoitemData
      loading: false,
      character: {}
    }
  }
  componentDidMount() {
    this.setState({ loading: true })
    fetch("https://swapi.co/api/people/")
      .then(response => response.json())
      .then(data => {
        this.setState({
          loading :false,
          character: data
        })
      })
  }
  render() {
    // const todoitem = this.state.todo.map(item =>
    //   <Todo key={item.id} item={item} />);
    const text = this.state.loading ? "loading..." : this.state.character.id
    return (
      <div>
        {text}
      </div>
      // { todoitem }
      // <div>
      //   <h1>Contact List</h1>
      //   <Todo name = {this.state.name} age= {this.state.age}/>
      // </div>
    )

  }
}
export default App;
