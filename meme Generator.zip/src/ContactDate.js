const employeeData =[{"id":"1","employee_name":"rujal","employee_salary":"12000","DOB":"2017-10-14T22:11:20"},
{"id":"224233","employee_name":"A2","employee_salary":"0","DOB":"2019-11-24T22:11:20"},
{"id":"224234","employee_name":"xdf","employee_salary":"52000","DOB":"2017-10-14T22:11:20"},
{"id":"224236","employee_name":"Lucy Kuhn","employee_salary":"373","DOB":"2018-07-07T22:11:20"},
{"id":"224246","employee_name":"km-test-3","employee_salary":"123","DOB":"2017-10-14T22:11:20"},
{"id":"224247","employee_name":"John2","employee_salary":"1","DOB":"2018-07-07T22:11:20"}]

const todoitemData =[
    {
        id:1,
        text : "Apples",
        completed: false
    },
    {
        id:2,
        text : "Mango",
        completed: true
    },
    {
        id:3,
        text : "Bananna",
        completed: false
    },
    {
        id:4,
        text : "BlueBerries",
        completed: true
    }
]

export default todoitemData;