import React from "react";
import Nav from './Nav';
import MemeGen from './MemeGen';

function App(){
return (
    <div>
        <Nav/>
        <MemeGen/>
    </div>
   
)
}

export default App;