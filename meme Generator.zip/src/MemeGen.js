import React, { Component } from "react";

class MemeGen extends Component {
    constructor() {
        super()
        this.state = {
            toptext: "",
            bottomtext: "",
            renderingImg: "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQfAoE4oIrzJ7DBQN-H-lUb-WpxpdrgjEmRxcnK4lAXREL0fZWF",
            allMemeImages: []
        }
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }
    componentDidMount() {
        fetch(" https://api.imgflip.com/get_memes")
            .then(response => response.json())
            .then(response => {
                const { meme } = response.data
                this.setState({ allMemeImages: meme })
            })
    }
    handleChange(event) {
        const { name, value } = event.target;
        this.setState({ [name]: value });
    }
    handleSubmit(event) {
        event.preventDefault()
        const randomnum = Math.floor(Math.random() * this.state.allMemeImages.length)
        const rendMemeImg = this.state.allMemeImages[randomnum].url
        this.setState({ renderingImg: rendMemeImg })
    }
    render() {
        return (
            <div>
                <form className="meme-form" onSubmit={this.handleSubmit}>
                    <input name="toptext" type="text"
                        placeholder="Top Text"
                        value={this.state.toptext}
                        onChange={this.handleChange} />
                    <input name="bottomtext" type="text"
                        placeholder="Bottom Text"
                        value={this.state.bottomtext}
                        onChange={this.handleChange}
                    />
                    <button>Generate</button>
                </form>
                <div className="meme">
                    <img src={this.state.renderingImg} />>
                    <h2 className="top">{this.state.toptext}</h2>
                    <h2 className="bottom">{this.state.bottomtext}</h2>
                </div>
            </div>
        )
    }
}

export default MemeGen;
